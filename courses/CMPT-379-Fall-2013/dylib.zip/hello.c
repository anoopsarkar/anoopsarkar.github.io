int
main () {
  greet();
}
