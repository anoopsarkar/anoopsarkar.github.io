#include <stdio.h>
void
greet () {
  printf("hello, world\n");
}
