use strict;

my $total = 0;

while (<>) {
  chomp;
  my @words = split;
  $total += $#words + 1;
}

print "$total\n";
