use strict;

my $line;
my $total = 0;

my $filename = "hw1.txt";
my $fh;

my $status = open($fh, $filename);
if (!$status) { die "could not open $filename\n"; }

while ($line = <$fh>) {
  chomp($line);
  my @words = split(' ', $line);
  $total += $#words + 1;
}

close($fh);
print "$total\n";
