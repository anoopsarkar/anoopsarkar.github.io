use strict;

my $total = 0;

while (<>) {
  chomp($_);
  my @words = split(' ', $_);
  $total += $#words + 1;
}

print "$total\n";
