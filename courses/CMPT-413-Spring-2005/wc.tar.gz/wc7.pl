use strict;

my $total = 0;

while (<>) {
  chomp;
  split;
  $total += $#_ + 1;
}

print "$total\n";
