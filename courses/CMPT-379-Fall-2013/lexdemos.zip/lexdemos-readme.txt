The readme is available at this link:
https://gist.github.com/anoopsarkar/6545633
