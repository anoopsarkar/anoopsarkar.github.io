
sample.tex contains the LaTeX source for the sample paper.

colacl06.sty and acl.bst are the style files that are used to format
the paper into the right layout style.

a makefile is provided: "make sample.pdf" will use pdflatex and
"make sample.ps" will use latex and dvips.

*.eps are figure files used when compiling using latex and then
dvips to create a postscript file as output.

*.pdf are figure files used when compiling using pdflatex to create
a pdf file as output.

Anoop Sarkar
anoop@cs.sfu.ca

