use strict;
my $line;
my $total = 0;
while ($line = <>) {
  chomp($line);
  my @words = split(' ', $line);
  $total += $#words + 1;
}
print "$total\n";
